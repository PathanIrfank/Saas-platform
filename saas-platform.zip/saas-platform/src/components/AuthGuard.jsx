import { useSelector } from "react-redux";
import { Navigate, useLocation } from "react-router-dom";

import { selectIsAuthenticated } from "../store/authSlice.js";

/**
 * Wrap any route element that requires a signed-in user:
 *   <Route path="/dashboard" element={<AuthGuard><DashboardPage /></AuthGuard>} />
 * Unauthenticated visitors are redirected to /login, and the original
 * destination is preserved in location state so login can send them back.
 */
export default function AuthGuard({ children }) {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}
