import { useDispatch, useSelector } from "react-redux";
import { NavLink, useNavigate } from "react-router-dom";

import { logout, selectAuthUser, selectIsAuthenticated } from "../store/authSlice.js";

const linkBase =
  "px-3 py-2 rounded-md text-sm font-medium transition-colors";
const linkActive = "bg-ink-800 text-white";
const linkIdle = "text-mist hover:text-white hover:bg-ink-800/60";

export default function Navbar() {
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const user = useSelector(selectAuthUser);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  return (
    <header className="border-b border-ink-800 bg-ink-900/80 backdrop-blur sticky top-0 z-10">
      <div className="mx-auto max-w-6xl px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <span className="font-display font-bold text-white tracking-tight">Nimbus</span>
          {isAuthenticated && (
            <nav className="flex items-center gap-1">
              <NavLink
                to="/dashboard"
                className={({ isActive }) => `${linkBase} ${isActive ? linkActive : linkIdle}`}
              >
                Dashboard
              </NavLink>
              <NavLink
                to="/settings"
                className={({ isActive }) => `${linkBase} ${isActive ? linkActive : linkIdle}`}
              >
                Settings
              </NavLink>
            </nav>
          )}
        </div>

        {isAuthenticated ? (
          <div className="flex items-center gap-3">
            <span className="text-sm text-mist">{user?.email}</span>
            <button
              onClick={handleLogout}
              className="text-sm font-medium px-3 py-1.5 rounded-md bg-ink-800 text-white hover:bg-ink-700 transition-colors"
            >
              Sign out
            </button>
          </div>
        ) : (
          <NavLink
            to="/login"
            className="text-sm font-medium px-3 py-1.5 rounded-md bg-brand-500 text-white hover:bg-brand-600 transition-colors"
          >
            Sign in
          </NavLink>
        )}
      </div>
    </header>
  );
}
