import { useSelector } from "react-redux";

import { selectAuthUser } from "../store/authSlice.js";

export default function SettingsPage() {
  const user = useSelector(selectAuthUser);

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-2xl font-bold text-white">Account settings</h1>
      <p className="text-mist mt-1">Manage your profile and tenant preferences.</p>

      <div className="mt-8 bg-ink-900 border border-ink-800 rounded-xl p-6 shadow-panel space-y-4">
        <div>
          <label className="block text-sm text-mist mb-1">Name</label>
          <input
            defaultValue={user?.name}
            className="w-full rounded-md bg-ink-800 border border-ink-700 px-3 py-2 text-sm text-white focus:border-brand-500"
          />
        </div>
        <div>
          <label className="block text-sm text-mist mb-1">Email</label>
          <input
            defaultValue={user?.email}
            className="w-full rounded-md bg-ink-800 border border-ink-700 px-3 py-2 text-sm text-white focus:border-brand-500"
          />
        </div>
        <div>
          <label className="block text-sm text-mist mb-1">Tenant</label>
          <input
            defaultValue={user?.tenant}
            disabled
            className="w-full rounded-md bg-ink-800/50 border border-ink-700 px-3 py-2 text-sm text-mist"
          />
        </div>
        <button className="rounded-md bg-brand-500 hover:bg-brand-600 text-white text-sm font-medium px-4 py-2 transition-colors">
          Save changes
        </button>
      </div>
    </div>
  );
}
