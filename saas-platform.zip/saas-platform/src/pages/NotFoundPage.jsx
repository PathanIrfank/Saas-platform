import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div className="min-h-[calc(100vh-56px)] flex flex-col items-center justify-center text-center px-4">
      <h1 className="text-5xl font-display font-extrabold text-white">404</h1>
      <p className="text-mist mt-2">This page doesn't exist.</p>
      <Link to="/" className="mt-6 text-brand-400 hover:text-brand-500 text-sm font-medium">
        Back to home
      </Link>
    </div>
  );
}
