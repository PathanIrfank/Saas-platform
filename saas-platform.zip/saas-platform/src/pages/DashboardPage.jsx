import { useSelector } from "react-redux";

import { selectAuthUser } from "../store/authSlice.js";

const stats = [
  { label: "Active tenants", value: "128" },
  { label: "MRR", value: "$42,900" },
  { label: "API requests (24h)", value: "1.2M" },
  { label: "Uptime (30d)", value: "99.98%" },
];

export default function DashboardPage() {
  const user = useSelector(selectAuthUser);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-2xl font-bold text-white">Welcome back, {user?.name}</h1>
      <p className="text-mist mt-1">Tenant: {user?.tenant}</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
        {stats.map((s) => (
          <div
            key={s.label}
            className="bg-ink-900 border border-ink-800 rounded-xl p-5 shadow-panel"
          >
            <p className="text-sm text-mist">{s.label}</p>
            <p className="text-2xl font-display font-bold text-white mt-1">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-ink-900 border border-ink-800 rounded-xl p-6 shadow-panel">
        <h2 className="text-lg font-semibold text-white mb-2">This is a lazily-loaded route</h2>
        <p className="text-sm text-mist">
          DashboardPage is code-split via <code className="text-brand-400">React.lazy</code> in{" "}
          <code className="text-brand-400">App.jsx</code>, so its bundle is only fetched once the
          user navigates here — and only after <code className="text-brand-400">AuthGuard</code>{" "}
          confirms they're signed in.
        </p>
      </div>
    </div>
  );
}
