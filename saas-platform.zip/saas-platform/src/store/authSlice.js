import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

// Swap this for a real POST /api/auth/login call against your backend.
async function fakeLoginRequest({ email, password }) {
  await new Promise((resolve) => setTimeout(resolve, 500));
  if (!email || !password) {
    throw new Error("Email and password are required.");
  }
  return {
    user: { id: "usr_1", email, name: email.split("@")[0], tenant: "acme-inc" },
    token: "demo-jwt-token",
  };
}

export const login = createAsyncThunk("auth/login", async (credentials, { rejectWithValue }) => {
  try {
    return await fakeLoginRequest(credentials);
  } catch (err) {
    return rejectWithValue(err.message);
  }
});

const initialState = {
  user: null,
  token: null,
  status: "idle", // idle | loading | succeeded | failed
  error: null,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout(state) {
      state.user = null;
      state.token = null;
      state.status = "idle";
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(login.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload ?? "Login failed";
      });
  },
});

export const { logout } = authSlice.actions;
export const selectIsAuthenticated = (state) => Boolean(state.auth.token);
export const selectAuthUser = (state) => state.auth.user;
export const selectAuthStatus = (state) => state.auth.status;
export const selectAuthError = (state) => state.auth.error;

export default authSlice.reducer;
