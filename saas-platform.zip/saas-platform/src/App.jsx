import { Suspense, lazy } from "react";
import { Navigate, Route, Routes } from "react-router-dom";

import AuthGuard from "./components/AuthGuard.jsx";
import Navbar from "./components/Navbar.jsx";

// Dynamic code splitting: each page ships as its own chunk, fetched on
// first navigation rather than bundled into the initial load.
const LoginPage = lazy(() => import("./pages/LoginPage.jsx"));
const DashboardPage = lazy(() => import("./pages/DashboardPage.jsx"));
const SettingsPage = lazy(() => import("./pages/SettingsPage.jsx"));
const NotFoundPage = lazy(() => import("./pages/NotFoundPage.jsx"));

function PageFallback() {
  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center">
      <div className="h-6 w-6 rounded-full border-2 border-ink-700 border-t-brand-500 animate-spin" />
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-ink-950">
      <Navbar />
      <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/dashboard"
            element={
              <AuthGuard>
                <DashboardPage />
              </AuthGuard>
            }
          />
          <Route
            path="/settings"
            element={
              <AuthGuard>
                <SettingsPage />
              </AuthGuard>
            }
          />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Suspense>
    </div>
  );
}
