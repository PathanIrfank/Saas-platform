# AI-Powered SaaS Web Platform

Modern multi-tenant web application built with React 18 and Redux Toolkit.
Features authentication guards, dynamic code splitting with `React.lazy`,
and Tailwind CSS UI components.

## Structure
```
src/
  App.jsx                 Routes, Suspense boundary, lazy-loaded pages
  main.jsx                 Entry point: Redux Provider + BrowserRouter
  index.css                 Tailwind entry + base styles
  store/
    store.js                 Redux Toolkit store
    authSlice.js              Auth state (login thunk, selectors, logout)
  components/
    AuthGuard.jsx              Route wrapper that redirects unauthenticated users
    Navbar.jsx                  Top nav, aware of auth state
  pages/
    LoginPage.jsx                Login form wired to the login thunk
    DashboardPage.jsx             Protected route (lazy-loaded)
    SettingsPage.jsx               Protected route (lazy-loaded)
    NotFoundPage.jsx                 404 fallback (lazy-loaded)
tailwind.config.js
postcss.config.js
vite.config.js
```

## Setup & run
```bash
npm install
npm run dev       # http://localhost:5173
npm run build      # production bundle
```

## How the pieces fit together
- **Auth**: `authSlice.js` holds `user`/`token`/`status` and exposes a
  `login` thunk (swap `fakeLoginRequest` for a real API call) plus memoized
  selectors (`selectIsAuthenticated`, `selectAuthUser`, ...).
- **Route protection**: `AuthGuard` reads `selectIsAuthenticated` and
  redirects to `/login` (preserving the intended destination in router
  state) when there's no session.
- **Code splitting**: every page in `App.jsx` is wrapped in `React.lazy`, so
  `/dashboard` and `/settings` are only downloaded when a user actually
  navigates there, behind a single `Suspense` fallback spinner.
- **Styling**: Tailwind utility classes with a small custom token set
  (`ink`/`brand`/`mist` colors, `Sora`/`Inter` type pairing) defined in
  `tailwind.config.js` — no component library, easy to restyle per tenant.

## Demo login
The login form accepts any email/password (see `fakeLoginRequest` in
`authSlice.js`) — replace it with a real `POST /api/auth/login` call and the
rest of the app (guards, selectors, UI) needs no changes.
